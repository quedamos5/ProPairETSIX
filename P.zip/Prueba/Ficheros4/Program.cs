﻿namespace Ficheros4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ficheros.FileExist();
            Ficheros.MakeFile();
            Ficheros.ReadFile();
        }
    }
}