﻿namespace Ficheros2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ficheros.CrearFichero();
            Ficheros.IntroducirNumeros();
            Ficheros.MinNumb();
            Ficheros.MaxNumb();
            Ficheros.Average();
        }
    }
}