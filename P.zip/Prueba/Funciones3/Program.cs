﻿namespace Funciones3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Ficheros.FileExist();
            Ficheros.ReadFile();
        }
    }
}