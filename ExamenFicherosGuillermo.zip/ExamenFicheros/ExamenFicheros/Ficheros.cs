﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFicheros
{
    internal class Ficheros
    {
        const string FILENAME = "poblacion-cifras-absolutas.csv", ENDFILE = "poblacion_datos_procesados.scv";
        public static List<string> lines = new(), data = new();
        public static List<int> numHab = new();
        public static int indexOfMun = 0, min = 0, indexOfYearMin = 0, max = 0, indexOfYearMax = 0;
        public static decimal minAvg = 0, maxAvg = 0; 

        public static bool FileExist(string fileName) => File.Exists(fileName);

        public static bool ReadFile()
        {
            try
            {
                lines = File.ReadAllLines(FILENAME).ToList();
                indexOfMun = Funciones.IndexOf("MUNICIPIO", lines[0].Split(';'));
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message); 
                return false;
            }
        }

        public static bool MakeFile()
        {
            try
            {
                File.Create(ENDFILE).Close();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool ValidateData()
        {
            string[] firstLine = lines[0].Split(';');
            if (!Funciones.ValidYear(firstLine))
            {
                Console.WriteLine("Error hay años inválidos en el fichero");
                return false;
            }

            for (int i = 1; i < lines.Count; i++)
            {
                string[] line = lines[i].Split(';');
                string input = "";
                
                if (Funciones.ValidMun(line[indexOfMun]))
                    input += line[indexOfMun] + ";";
                else
                {
                    Console.WriteLine($"Error, el municipio de la línea {i} no es válido");
                    return false;
                }
                
                if (Funciones.ValorMin(line))
                    input += firstLine[indexOfYearMin].Split('_')[1] + ";" + min + ";";
                else
                {
                    Console.WriteLine($"Error, los datos de la linea {i} no son válidos");
                    return false;
                }

                if (Funciones.ValorMax(line))
                {
                    double avg = numHab.Average();
                    input += firstLine[indexOfYearMax].Split('_')[1] + ";" + max + ";" + $"{avg:f2}";
                }
                else
                {
                    Console.WriteLine($"Error, los datos de la linea {i} no son válidos");
                    return false;
                }
                numHab = new();

                data.Add(input);
            }

            return true;
        }

        public static bool WriteFile()
        {
            StreamWriter sw = null;

            try
            {
                sw = new StreamWriter(ENDFILE);
                sw.WriteLine("Municipio;AñoMin;ValorMin;AñoMax;ValorMax;Media");
                for (int i = 0; i < data.Count; i++)
                    sw.WriteLine(data[i]);
                sw.Close();
                Process.Start("notepad.exe", ENDFILE);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool MinMaxAvg()
        {
            StreamReader sr = null;

            try
            {
                sr = new StreamReader(ENDFILE);
                sr.ReadLine();
                minAvg = maxAvg = Convert.ToDecimal(sr.ReadLine().Split(';')[^1]);

                while (!sr.EndOfStream)
                {
                    decimal currentNumb = Convert.ToDecimal(sr.ReadLine().Split(';')[^1]);
                    if (currentNumb > maxAvg)
                        maxAvg = currentNumb;
                    if (currentNumb < minAvg)
                        minAvg = currentNumb;
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public static bool ShowInfo(decimal value) { 
        
            try
            {
                List<string> linesEndFile = File.ReadAllLines(ENDFILE).ToList();

                for (int i = 1; i < linesEndFile.Count; i++)
                {
                    string[] line = linesEndFile[i].Split(';');
                    if (Convert.ToDecimal(line[^1]) >= value)
                    {
                        Console.WriteLine($"{line[0]}\t-->\t{line[^1]}");
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }


        }

    }
}
