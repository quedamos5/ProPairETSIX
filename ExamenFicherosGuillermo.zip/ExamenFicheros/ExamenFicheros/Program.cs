﻿namespace ExamenFicheros
{
    class Program
    {
        static void Main(string[] args)
        {
            bool value = false;
            if (Ficheros.FileExist("poblacion-cifras-absolutas.csv"))
                if (Ficheros.ReadFile())
                    if (Ficheros.ValidateData())
                        if (Ficheros.MakeFile())
                            if (Ficheros.WriteFile())
                                value = true;
                        else
                            Console.WriteLine("Error, no se pudo crear 'poblacion_datos_procesados.csv'");
                else
                    Console.WriteLine("No se pudo leer el fichero 'poblacion-cifras-absolutas.csv'");
            else
                Console.WriteLine("El fichero 'poblacion-cifras-absolutas.csv no existe'");
            Ficheros.ValidateData();
            Ficheros.WriteFile();

            if (value)
            {
                if(Ficheros.MinMaxAvg())
                {
                    if (!Ficheros.ShowInfo(Funciones.FilterNumb()))
                    {
                        Console.WriteLine("Error al leer el fichero 'poblacion_datos_procesados.csv'");
                    }
                }
                else
                {
                    Console.WriteLine("Error al leer el fichero 'poblacion_datos_procesados.csv'");
                }
            }
        }
    }
}