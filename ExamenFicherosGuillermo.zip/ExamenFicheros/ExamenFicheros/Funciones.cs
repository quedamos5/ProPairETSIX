﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenFicheros
{
    internal class Funciones
    {
        public static int IndexOf(string search, string[] line)
        {
            for (int i = 0; i < line.Length; i++)
                if (line[i] == search)
                    return i;
            return -1;
        }

        public static bool ValidMun(string mun) => mun.Trim() != "";

        public static bool ValidYear(string[] line)
        {
            int year = 0;
            for (int i = Ficheros.indexOfMun + 1; i < line.Length; i++ )
            {
                if (Int32.TryParse(line[i].Split('_')[1], out year))
                {
                    if (!(year >= 2000 && year <= 2023))
                        return false;
                }
                else
                    return false;
            }
            return true;
        }

        public static bool ValorMin(string[] line)
        {
            int currentNumb = 0, indexOfMun = Ficheros.indexOfMun,
                min = Ficheros.min;
            for (int i = indexOfMun + 1; i < line.Length; i++)
            {
                if (i == indexOfMun + 1)
                    if (IsNumb(line[i]) && ValidNumb(line[i]))
                    {
                        min = Convert.ToInt32(line[i]);
                        Ficheros.indexOfYearMin = i;
                    }
                    else
                        return false;

                if (IsNumb(line[i]) && ValidNumb(line[i]))
                {
                    currentNumb = Convert.ToInt32(line[i]);
                    if (min > currentNumb)
                    {
                        min = currentNumb;
                        Ficheros.indexOfYearMin = i;
                    }
                } else
                {
                    return false;
                }

            }
            return true;
        }

        public static bool ValorMax(string[] line)
        {
            int currentNumb = 0, indexOfMun = Ficheros.indexOfMun,
                max = Ficheros.max;
            for (int i = indexOfMun + 1; i < line.Length; i++)
            {
                if (i == indexOfMun + 1)
                    if (IsNumb(line[i]) && ValidNumb(line[i]))
                    {
                        max = Convert.ToInt32(line[i]);
                        Ficheros.indexOfYearMax = i;
                    }
                    else
                        return false;

                if (IsNumb(line[i]) && ValidNumb(line[i]))
                {
                    currentNumb = Convert.ToInt32(line[i]);
                    if (max < currentNumb)
                    {
                        max = currentNumb;
                        Ficheros.indexOfYearMax = i;
                    }
                }
                else
                {
                    return false;
                }
                Ficheros.numHab.Add(currentNumb);
            }
            return true;
        }


        public static bool IsNumb(string data) => Int32.TryParse(data, out _);

        public static bool ValidNumb(string data) => Convert.ToInt32(data) >= 0;

        public static decimal FilterNumb()
        {
            decimal numb, min = Ficheros.minAvg, max = Ficheros.maxAvg;
            do
            {
                Console.WriteLine($"Introduce un número decimal entre {min} y {max}");
            } while (!Decimal.TryParse(Console.ReadLine().Replace('.', ','), out numb) || numb < min || numb > max);

            return numb;
        }
    }
}
